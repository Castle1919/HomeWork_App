cd my_project || exit

source venv/bin/activate

python manage.py runserver
