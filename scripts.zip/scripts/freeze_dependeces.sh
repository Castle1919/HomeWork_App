source venv/bin/activate

pip freeze > requirements.txt

echo "Зависимости сохранены в requirements.txt!"
